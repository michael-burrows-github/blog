import StarRating from "./StarRating";
import "./App.css";

const App = () => {
  return (
    <div className="App">
      <StarRating />
    </div>
  );
};

export default App;
